AnimatedListView for Android
============================

AnimatedListView is an Android ListView implementation that animates views into place, similar to the Google Plus app on Android.

The library is very simple to use, and only consists of three classes. Simply add the Library to to your project, and [follow the usage instructions described here](http://kylewbanks.com/post/show/Open-Sourced-AnimatedListView-Android-Library).

For an example of an application that used this library, checkout of the [KyleWBanks.com Android App](https://github.com/KyleBanks/kylewbanks.com-AndroidApp).
