/*
 * Copyright (c) 2013 Kyle W. Banks
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.kylewbanks.animlv;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListAdapter;
import android.widget.ListView;

/**
 * The actual ListView that will display the animations.
 *
 * For now it does nothing a normal ListView can't do, but that may change in the future.
 */
public class AnimatedListView extends ListView {

    public AnimatedListView(Context context) {
        this(context, null);
    }

    public AnimatedListView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AnimatedListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void setAdapter(ListAdapter adapter) {
        if (adapter instanceof AnimatedListViewAdapter) {
            super.setAdapter(adapter);
        } else {
            throw new UnsupportedOperationException("AnimatedListView requires a ListAdapter of type AnimatedListViewAdapter");
        }
    }
}
